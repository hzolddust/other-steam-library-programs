"""
RedX Game Library - Configuration Module
Contains global configurations, constants, API URLs, and file path resolvers.
"""

import os
import sys

# Application Version & Identity
APP_NAME = "RedX Game Library"
APP_VERSION = "2.4.7"
APP_AUTHOR = "RedX Team"
ORGANIZATION_NAME = "RedX"

# API & Remote Endpoints
API_BASE_URL = "https://redxhub.com/api"
API_FIX_SCRIPT_URL = "https://redxhub.com/raw/fix.ps1"
STEAM_FIX_URL = "https://steam.run"
MANIFESTHUB_API_URL = "https://manifesthub.org/api"
STEAMCMD_API_URL = "https://api.steamcmd.net/v1"
STEAM_STORE_URL = "https://store.steampowered.com"
STEAM_CDN_COMMUNITY = "https://steamcommunity-a.akamaihd.net/economy/image/"
STEAM_CDN_STORE = "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps"

# Local Storage Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOCAL_APPDATA = os.getenv("LOCALAPPDATA", os.path.join(os.path.expanduser("~"), "AppData", "Local"))
APP_DATA_DIR = os.path.join(LOCAL_APPDATA, "RedX Game Library")
STEAM_DATA_DIR = os.path.join(APP_DATA_DIR, "steam_data")
CACHE_DIR = os.path.join(APP_DATA_DIR, "cache")
DOWNLOADS_DIR = os.path.join(APP_DATA_DIR, "resources", "temp_downloads")
ICONS_DIR = os.path.join(BASE_DIR, "resources", "icons")

# Ensure required directories exist
for directory in [APP_DATA_DIR, STEAM_DATA_DIR, CACHE_DIR, DOWNLOADS_DIR]:
    try:
        os.makedirs(directory, exist_ok=True)
    except Exception:
        pass


def get_icon_path(icon_name: str) -> str:
    """Helper to resolve icon paths from the resources directory."""
    candidates = [
        os.path.join(ICONS_DIR, icon_name),
        os.path.join(ICONS_DIR, f"{icon_name}.svg"),
        os.path.join(ICONS_DIR, f"{icon_name}.png"),
        os.path.join(BASE_DIR, "resources", icon_name),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return ""


# UI Color Palette & Styling
THEME = {
    "background_dark": "#0d0f14",
    "background_card": "#151922",
    "background_card_hover": "#1c222e",
    "sidebar_bg": "#0a0c10",
    "accent_red": "#e50914",
    "accent_red_hover": "#ff1e27",
    "accent_blue": "#3b82f6",
    "accent_green": "#10b981",
    "accent_yellow": "#f59e0b",
    "text_primary": "#ffffff",
    "text_secondary": "#9ca3af",
    "text_muted": "#6b7280",
    "border_color": "#222734",
    "border_focus": "#3b82f6",
}
