"""
RedX Game Library - Cart Manager
Thread-safe singleton manager for bulk game selection cart (max 5 games).
"""

from typing import List, Dict, Any, Tuple


class CartManager:
    _instance = None
    _cart = []
    MAX_GAMES = 5

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = CartManager()
        return cls._instance

    def add(self, game_data: Dict[str, Any]) -> Tuple[bool, str]:
        """Add game to cart. Returns (success, message)."""
        app_id = game_data.get("app_id") or game_data.get("appid")
        if not app_id:
            return False, "Geçersiz oyun kimliği."

        if self.is_selected(app_id):
            return False, "Oyun zaten sepete eklenmiş."

        if len(self._cart) >= self.MAX_GAMES:
            return False, f"En fazla {self.MAX_GAMES} oyun seçebilirsiniz."

        self._cart.append(game_data)
        return True, "Oyun sepete eklendi."

    def remove(self, app_id: int) -> bool:
        """Removes game from cart."""
        initial_len = len(self._cart)
        self._cart = [g for g in self._cart if (g.get("app_id") or g.get("appid")) != app_id]
        return len(self._cart) < initial_len

    def toggle(self, game_data: Dict[str, Any]) -> Tuple[bool, str]:
        """Toggles game in cart. Returns (is_now_selected, message)."""
        app_id = game_data.get("app_id") or game_data.get("appid")
        if self.is_selected(app_id):
            self.remove(app_id)
            return False, "Oyun sepetten çıkarıldı."
        else:
            success, msg = self.add(game_data)
            return success, msg

    def is_selected(self, app_id: int) -> bool:
        """Returns True if the app_id is in cart."""
        return any((g.get("app_id") or g.get("appid")) == app_id for g in self._cart)

    def count(self) -> int:
        return len(self._cart)

    def get_cart(self) -> List[Dict[str, Any]]:
        return list(self._cart)

    def clear(self):
        self._cart.clear()
