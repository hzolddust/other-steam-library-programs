"""
RedX Game Library - Update Manager
Checks remote version, compares semantic versions, creates PowerShell update script, and restarts application.
"""

import os
import sys
import subprocess
from typing import Tuple, Optional

from config import APP_VERSION, APP_DATA_DIR, API_BASE_URL


class UpdateManager:
    def __init__(self, api_client=None):
        self.api_client = api_client
        self.current_version = APP_VERSION

    def is_newer_version(self, remote_version: str) -> bool:
        """Compares current version with remote version (e.g. 2.4.7 vs 2.4.8)."""
        try:
            cur_parts = [int(p) for p in self.current_version.split(".")]
            rem_parts = [int(p) for p in remote_version.split(".")]
            return rem_parts > cur_parts
        except Exception:
            return False

    def check_for_updates(self) -> Tuple[bool, Optional[str], Optional[str]]:
        """Returns (has_update, new_version, download_url)."""
        if not self.api_client:
            return False, None, None
        try:
            info = self.api_client.check_for_updates()
            if info:
                latest_ver = info.get("version", "")
                download_url = info.get("download_url", "")
                if self.is_newer_version(latest_ver):
                    return True, latest_ver, download_url
        except Exception:
            pass
        return False, None, None

    def apply_update_and_restart(self, new_exe_path: str):
        """Replaces current executable using PowerShell script and restarts."""
        script_path = os.path.join(APP_DATA_DIR, "updater.ps1")
        current_exe = sys.executable
        pid = os.getpid()

        ps_script = f"""
Start-Sleep -Seconds 2
Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue
Copy-Item -Path "{new_exe_path}" -Destination "{current_exe}" -Force
Start-Process -FilePath "{current_exe}"
Remove-Item -Path "{new_exe_path}" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "{script_path}" -Force -ErrorAction SilentlyContinue
"""
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(ps_script)

        subprocess.Popen(["powershell", "-WindowStyle", "Hidden", "-File", script_path], shell=True)
        sys.exit(0)
