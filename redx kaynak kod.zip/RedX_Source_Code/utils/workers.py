"""
RedX Game Library - Background Workers (PyQt6 QThread)
Non-blocking background tasks:
- DownloadWorker: Handles game/manifest/tool downloads with progress signaling
- UpdateWorker: Background update checks and execution
- ImageLoadWorker: Async image fetching and caching
- LiveScrapeWorker: Scrapes live online fixes
"""

import os
import requests
from PyQt6.QtCore import QThread, pyqtSignal


class DownloadWorker(QThread):
    progress = pyqtSignal(int, int) # (downloaded, total)
    finished = pyqtSignal(bool, str) # (success, destination_path)

    def __init__(self, url: str, destination: str):
        super().__init__()
        self.url = url
        self.destination = destination
        self._is_cancelled = False

    def run(self):
        try:
            os.makedirs(os.path.dirname(self.destination), exist_ok=True)
            with requests.get(self.url, stream=True, timeout=30) as r:
                r.raise_for_status()
                total = int(r.headers.get('content-length', 0))
                downloaded = 0
                with open(self.destination, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        if self._is_cancelled:
                            self.finished.emit(False, "Cancelled")
                            return
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            self.progress.emit(downloaded, total)
            self.finished.emit(True, self.destination)
        except Exception as e:
            self.finished.emit(False, str(e))

    def cancel(self):
        self._is_cancelled = True


class ImageLoadWorker(QThread):
    loaded = pyqtSignal(bytes, str) # (image_bytes, identifier)

    def __init__(self, url: str, identifier: str):
        super().__init__()
        self.url = url
        self.identifier = identifier

    def run(self):
        try:
            resp = requests.get(self.url, timeout=8)
            if resp.status_code == 200:
                self.loaded.emit(resp.content, self.identifier)
        except Exception:
            pass


class UpdateWorker(QThread):
    update_available = pyqtSignal(str, str) # (version, download_url)

    def __init__(self, update_manager):
        super().__init__()
        self.update_manager = update_manager

    def run(self):
        has_update, new_ver, dl_url = self.update_manager.check_for_updates()
        if has_update and new_ver and dl_url:
            self.update_available.emit(new_ver, dl_url)


class LiveScrapeWorker(QThread):
    scraped = pyqtSignal(list)

    def __init__(self, api_client):
        super().__init__()
        self.api_client = api_client

    def run(self):
        try:
            games = self.api_client.get_games_data()
            self.scraped.emit(games)
        except Exception:
            self.scraped.emit([])
