"""
RedX Game Library - API Client Module
Handles all network communications with RedX API, ManifestHub, Steam store, and SteamCMD:
- Fetching games catalog, metadata, images, and online fixes
- Submitting game requests, complaints, and suggestions
- Validating and exchanging ManifestHub keys
- Tracking download metrics and user votes
"""

import os
import json
import requests
from typing import Dict, List, Optional, Any

from config import (
    API_BASE_URL,
    MANIFESTHUB_API_URL,
    STEAMCMD_API_URL,
    STEAM_STORE_URL,
    APP_VERSION
)
from backend.backend_bridge import RedXBackend


class APIClient:
    def __init__(self):
        self.session = self._create_session()
        self.backend = RedXBackend()
        self.hwid = self.backend.generate_hwid()
        self.headers = {
            "User-Agent": f"RedXGameLibrary/{APP_VERSION} (Windows NT 10.0; Win64; x64)",
            "X-HWID": self.hwid,
            "Accept": "application/json",
        }

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(max_retries=3)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def get_games_data(self) -> List[Dict[str, Any]]:
        """Fetches complete game library catalog from RedX backend."""
        try:
            url = f"{API_BASE_URL}/games"
            resp = self.session.get(url, headers=self.headers, timeout=10)
            if resp.status_code == 200:
                return resp.json().get("games", [])
        except Exception as e:
            print(f"[APIClient] Error fetching games: {e}")
        return []

    def get_game_details(self, app_id: int) -> Optional[Dict[str, Any]]:
        """Fetches detailed game metadata including screenshots, description, and requirements from Steam."""
        try:
            url = f"{STEAM_STORE_URL}/api/appdetails?appids={app_id}&l=turkish"
            resp = self.session.get(url, timeout=8)
            if resp.status_code == 200:
                data = resp.json()
                if str(app_id) in data and data[str(app_id)].get("success"):
                    return data[str(app_id)].get("data", {})
        except Exception as e:
            print(f"[APIClient] Error fetching Steam details for {app_id}: {e}")
        return None

    def get_bypass_data(self, app_id: int) -> Optional[Dict[str, Any]]:
        """Fetches bypass details, online fixes, and manifest URLs for a game."""
        try:
            url = f"{API_BASE_URL}/bypass/{app_id}"
            resp = self.session.get(url, headers=self.headers, timeout=8)
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            print(f"[APIClient] Error fetching bypass data: {e}")
        return None

    def get_steamcmd_info(self, app_id: int) -> Optional[Dict[str, Any]]:
        """Fetches game manifests and depot versions from SteamCMD API."""
        try:
            url = f"{STEAMCMD_API_URL}/info/{app_id}"
            resp = self.session.get(url, timeout=8)
            if resp.status_code == 200:
                return resp.json().get("data", {}).get(str(app_id), {})
        except Exception as e:
            print(f"[APIClient] SteamCMD API error: {e}")
        return None

    def get_download_counts(self) -> Dict[str, int]:
        """Fetches download counts per game."""
        try:
            url = f"{API_BASE_URL}/stats/downloads"
            resp = self.session.get(url, headers=self.headers, timeout=5)
            if resp.status_code == 200:
                return resp.json().get("counts", {})
        except Exception:
            pass
        return {}

    def update_download_count(self, app_id: int):
        """Notifies API of a game download/installation."""
        try:
            url = f"{API_BASE_URL}/stats/download"
            self.session.post(url, json={"app_id": app_id, "hwid": self.hwid}, headers=self.headers, timeout=4)
        except Exception:
            pass

    def check_for_updates(self) -> Optional[Dict[str, Any]]:
        """Checks for application updates."""
        try:
            url = f"{API_BASE_URL}/version"
            resp = self.session.get(url, headers=self.headers, timeout=6)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None

    def send_game_request(self, game_name: str, steam_link: str, note: str = "") -> bool:
        """Submits a game request."""
        try:
            url = f"{API_BASE_URL}/requests/submit"
            payload = {"game_name": game_name, "steam_link": steam_link, "note": note, "hwid": self.hwid}
            resp = self.session.post(url, json=payload, headers=self.headers, timeout=8)
            return resp.status_code in [200, 201]
        except Exception:
            return False

    def get_game_requests(self) -> List[Dict[str, Any]]:
        """Fetches list of community requested games."""
        try:
            url = f"{API_BASE_URL}/requests/list"
            resp = self.session.get(url, headers=self.headers, timeout=8)
            if resp.status_code == 200:
                return resp.json().get("requests", [])
        except Exception:
            pass
        return []

    def vote_game_request(self, request_id: int) -> bool:
        """Votes for a requested game."""
        try:
            url = f"{API_BASE_URL}/requests/vote"
            resp = self.session.post(url, json={"id": request_id, "hwid": self.hwid}, headers=self.headers, timeout=5)
            return resp.status_code == 200
        except Exception:
            return False

    def send_complaint(self, text: str, category: str = "general") -> bool:
        """Submits a bug report / complaint."""
        try:
            url = f"{API_BASE_URL}/feedback/complaint"
            payload = {"text": text, "category": category, "hwid": self.hwid}
            resp = self.session.post(url, json=payload, headers=self.headers, timeout=8)
            return resp.status_code in [200, 201]
        except Exception:
            return False

    def send_suggestion(self, text: str) -> bool:
        """Submits a user suggestion."""
        try:
            url = f"{API_BASE_URL}/feedback/suggestion"
            payload = {"text": text, "hwid": self.hwid}
            resp = self.session.post(url, json=payload, headers=self.headers, timeout=8)
            return resp.status_code in [200, 201]
        except Exception:
            return False

    def download_from_url(self, url: str, destination_path: str, progress_callback=None) -> bool:
        """Downloads a remote file with progress tracking."""
        try:
            os.makedirs(os.path.dirname(destination_path), exist_ok=True)
            with self.session.get(url, stream=True, timeout=30) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('content-length', 0))
                downloaded = 0
                with open(destination_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if progress_callback and total_size > 0:
                                progress_callback(downloaded, total_size)
            return True
        except Exception as e:
            print(f"[APIClient] Download error: {e}")
            return False
