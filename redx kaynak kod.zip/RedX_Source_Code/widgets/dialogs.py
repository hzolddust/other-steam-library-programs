"""
RedX Game Library - Dialogs Collection
"""
import os
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QWidget, QFrame, QLineEdit, QTextEdit
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap

from config import THEME, get_icon_path
from api.api_client import APIClient
from utils.steam_manager import SteamManager


class GameDetailDialog(QDialog):
    def __init__(self, game_data: dict, parent=None):
        super().__init__(parent)
        self.game_data = game_data
        self.app_id = game_data.get("app_id") or game_data.get("appid", 0)
        self.name = game_data.get("name", "Oyun Detayları")
        self.api_client = APIClient()
        self.steam_manager = SteamManager.get_instance()

        self.setWindowTitle(self.name)
        self.resize(850, 600)
        self.setStyleSheet(f"background-color: {THEME['background_dark']}; color: white;")
        self.setup_ui()
        self.fetch_details()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        header = QHBoxLayout()
        title = QLabel(self.name)
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: white;")
        header.addWidget(title)
        header.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setFixedSize(30, 30)
        close_btn.setStyleSheet("background: transparent; color: #9ca3af; font-size: 16px; border: none;")
        close_btn.clicked.connect(self.accept)
        header.addWidget(close_btn)

        layout.addLayout(header)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background: transparent;")

        container = QWidget()
        c_layout = QVBoxLayout(container)
        c_layout.setSpacing(14)

        self.hero_label = QLabel()
        self.hero_label.setFixedHeight(220)
        self.hero_label.setStyleSheet(f"background-color: {THEME['background_card']}; border-radius: 10px;")
        self.hero_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hero_label.setText("Görsel yükleniyor...")
        c_layout.addWidget(self.hero_label)

        desc_title = QLabel("Hakkında")
        desc_title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        c_layout.addWidget(desc_title)

        self.desc_label = QLabel("Açıklama getiriliyor...")
        self.desc_label.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 13px; line-height: 1.4;")
        self.desc_label.setWordWrap(True)
        c_layout.addWidget(self.desc_label)

        actions = QHBoxLayout()
        self.install_btn = QPushButton("⚡ Kütüphaneye Ekle ve Yükle")
        self.install_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['accent_red']};
                color: white;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {THEME['accent_red_hover']};
            }}
        """)
        self.install_btn.clicked.connect(self._on_install)
        actions.addWidget(self.install_btn)

        self.fix_btn = QPushButton("🔧 Online Fix Yükle")
        self.fix_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['background_card']};
                color: white;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 13px;
                border: 1px solid {THEME['border_color']};
            }}
            QPushButton:hover {{
                background-color: {THEME['background_card_hover']};
            }}
        """)
        actions.addWidget(self.fix_btn)
        actions.addStretch()

        c_layout.addLayout(actions)
        scroll.setWidget(container)
        layout.addWidget(scroll)

    def fetch_details(self):
        details = self.api_client.get_game_details(self.app_id)
        if details:
            short_desc = details.get("short_description", "Açıklama bulunamadı.")
            self.desc_label.setText(short_desc)
            header_img = details.get("header_image", "")
            if header_img:
                from utils.workers import ImageLoadWorker
                self.worker = ImageLoadWorker(header_img, str(self.app_id))
                self.worker.loaded.connect(self._on_hero_loaded)
                self.worker.start()

    def _on_hero_loaded(self, img_bytes: bytes, _):
        pixmap = QPixmap()
        if pixmap.loadFromData(img_bytes):
            scaled = pixmap.scaled(
                780, 220,
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation
            )
            self.hero_label.setPixmap(scaled)
            self.hero_label.setText("")

    def _on_install(self):
        self.steam_manager.run_steam_firewall_cycle()
        dialog = SteamRestartSuccessDialog(self)
        dialog.exec()


class VersionSelectionDialog(QDialog):
    def __init__(self, versions: list, parent=None):
        super().__init__(parent)
        self.versions = versions
        self.selected_version = None
        self.setWindowTitle("Sürüm Seçimi")
        self.resize(500, 400)
        self.setStyleSheet(f"background-color: {THEME['background_dark']}; color: white;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Yüklenecek Sürümü Seçin")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        layout.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background: transparent;")

        container = QWidget()
        c_layout = QVBoxLayout(container)
        c_layout.setSpacing(8)

        for v in self.versions:
            btn = QPushButton(f"Sürüm {v.get('version', 'v1.0')} - {v.get('date', 'Güncel')}")
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {THEME['background_card']};
                    color: white;
                    border-radius: 8px;
                    padding: 10px;
                    text-align: left;
                    border: 1px solid {THEME['border_color']};
                }}
                QPushButton:hover {{
                    border: 1px solid {THEME['accent_blue']};
                }}
            """)
            btn.clicked.connect(lambda _, ver=v: self._select(ver))
            c_layout.addWidget(btn)

        scroll.setWidget(container)
        layout.addWidget(scroll)

    def _select(self, ver):
        self.selected_version = ver
        self.accept()


class SteamRestartSuccessDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("İşlem Başarılı")
        self.setFixedSize(400, 220)
        self.setStyleSheet(f"background-color: {THEME['background_card']}; color: white; border-radius: 12px;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        icon_lbl = QLabel("✅")
        icon_lbl.setStyleSheet("font-size: 32px;")
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_lbl)

        title = QLabel("Steam Başarıyla Yenilendi!")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        msg = QLabel("Oyun Steam kütüphanenize eklendi. Steam istemcinizden oyunu görebilirsiniz.")
        msg.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 12px;")
        msg.setWordWrap(True)
        msg.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(msg)

        ok_btn = QPushButton("Tamam")
        ok_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['accent_red']};
                color: white;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: bold;
            }}
        """)
        ok_btn.clicked.connect(self.accept)
        layout.addWidget(ok_btn)


class SteamCheckGamesDialog(QDialog):
    def __init__(self, missing_games: list, parent=None):
        super().__init__(parent)
        self.missing_games = missing_games
        self.setWindowTitle("Kayıp Oyun Tespiti")
        self.resize(450, 320)
        self.setStyleSheet(f"background-color: {THEME['background_dark']}; color: white;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Kütüphanede Tespit Edilmeyen Oyunlar")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: white;")
        layout.addWidget(title)

        msg = QLabel(f"{len(self.missing_games)} adet oyunun Steam manifest dosyaları eksik görünüyor.")
        msg.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 12px;")
        layout.addWidget(msg)

        fix_btn = QPushButton("Manifestleri Otomatik Onar")
        fix_btn.setStyleSheet(f"background-color: {THEME['accent_red']}; color: white; padding: 8px; border-radius: 6px; font-weight: bold;")
        layout.addWidget(fix_btn)


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ayarlar")
        self.resize(500, 420)
        self.setStyleSheet(f"background-color: {THEME['background_dark']}; color: white;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        title = QLabel("Ayarlar")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        layout.addWidget(title)

        mh_lbl = QLabel("ManifestHub API Anahtarı:")
        mh_lbl.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 12px;")
        layout.addWidget(mh_lbl)

        self.mh_input = QLineEdit()
        self.mh_input.setPlaceholderText("API anahtarınızı buraya girin...")
        self.mh_input.setStyleSheet(f"background-color: {THEME['background_card']}; border: 1px solid {THEME['border_color']}; border-radius: 6px; padding: 8px; color: white;")
        layout.addWidget(self.mh_input)

        test_key_btn = QPushButton("Anahtarı Test Et")
        test_key_btn.setStyleSheet(f"background-color: {THEME['accent_blue']}; color: white; border-radius: 6px; padding: 6px 12px; font-weight: bold;")
        layout.addWidget(test_key_btn)

        layout.addStretch()

        save_btn = QPushButton("Kaydet ve Kapat")
        save_btn.setStyleSheet(f"background-color: {THEME['accent_red']}; color: white; border-radius: 6px; padding: 10px; font-weight: bold;")
        save_btn.clicked.connect(self.accept)
        layout.addWidget(save_btn)


class RequestGameDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.api_client = APIClient()
        self.setWindowTitle("Oyun İstek Formu")
        self.resize(450, 350)
        self.setStyleSheet(f"background-color: {THEME['background_dark']}; color: white;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        title = QLabel("Yeni Oyun Talep Et")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        layout.addWidget(title)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Oyun Adı")
        self.name_input.setStyleSheet(f"background-color: {THEME['background_card']}; border: 1px solid {THEME['border_color']}; border-radius: 6px; padding: 8px; color: white;")
        layout.addWidget(self.name_input)

        self.link_input = QLineEdit()
        self.link_input.setPlaceholderText("Steam Mağaza Linki (isteğe bağlı)")
        self.link_input.setStyleSheet(f"background-color: {THEME['background_card']}; border: 1px solid {THEME['border_color']}; border-radius: 6px; padding: 8px; color: white;")
        layout.addWidget(self.link_input)

        self.note_input = QTextEdit()
        self.note_input.setPlaceholderText("Eklemek istediğiniz not...")
        self.note_input.setStyleSheet(f"background-color: {THEME['background_card']}; border: 1px solid {THEME['border_color']}; border-radius: 6px; padding: 8px; color: white;")
        layout.addWidget(self.note_input)

        send_btn = QPushButton("Talebi Gönder")
        send_btn.setStyleSheet(f"background-color: {THEME['accent_red']}; color: white; border-radius: 6px; padding: 10px; font-weight: bold;")
        send_btn.clicked.connect(self._send)
        layout.addWidget(send_btn)

    def _send(self):
        name = self.name_input.text().strip()
        link = self.link_input.text().strip()
        note = self.note_input.toPlainText().strip()
        if name:
            self.api_client.send_game_request(name, link, note)
            self.accept()


class SupportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Geliştiriciye Destek Ol")
        self.setFixedSize(400, 250)
        self.setStyleSheet(f"background-color: {THEME['background_card']}; color: white;")
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(14)

        title = QLabel("RedX Geliştiricilerini Destekleyin")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        desc = QLabel("RedX Game Library ücretsiz bir projedir. Bizi destekleyerek sunucu ve geliştirme masraflarına katkıda bulunabilirsiniz.")
        desc.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 12px;")
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(desc)

        patreon_btn = QPushButton("❤️ Patreon ile Destek Ol")
        patreon_btn.setStyleSheet("background-color: #ff424d; color: white; padding: 8px; border-radius: 6px; font-weight: bold;")
        layout.addWidget(patreon_btn)

        bmc_btn = QPushButton("☕ Buy Me a Coffee")
        bmc_btn.setStyleSheet("background-color: #ffd000; color: black; padding: 8px; border-radius: 6px; font-weight: bold;")
        layout.addWidget(bmc_btn)
