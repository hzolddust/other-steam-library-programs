"""
RedX Game Library - Main Window
"""
import os
import sys
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QScrollArea, QGridLayout, QStackedWidget, QSystemTrayIcon,
    QMenu, QFrame, QMessageBox
)
from PyQt6.QtCore import Qt, QPoint, QSize, QTimer
from PyQt6.QtGui import QIcon, QCursor

from config import (
    APP_NAME, APP_VERSION, THEME, get_icon_path
)
from api.api_client import APIClient
from backend.backend_bridge import RedXBackend
from utils.steam_manager import SteamManager
from utils.cart_manager import CartManager
from utils.update_manager import UpdateManager
from utils.workers import UpdateWorker, LiveScrapeWorker
from widgets.game_card import GameCard
from widgets.steam_view import SteamView
from widgets.tools_view import ToolsView
from widgets.dialogs import (
    GameDetailDialog,
    SettingsDialog,
    RequestGameDialog,
    SupportDialog
)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.api_client = APIClient()
        self.backend = RedXBackend()
        self.steam_manager = SteamManager.get_instance()
        self.cart_manager = CartManager.get_instance()
        self.update_manager = UpdateManager(self.api_client)

        self.all_games = []
        self.filtered_games = []
        self.installed_appids = set(self.backend.get_steam_installed_appids(self.steam_manager.steam_path))
        self.current_page = 1
        self.games_per_page = 12

        self._drag_pos = QPoint()

        self.setup_window()
        self.setup_ui()
        self.setup_tray_icon()
        self.load_games_data()
        self.check_for_updates()

    def setup_window(self):
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.resize(1180, 720)
        self.setMinimumSize(950, 600)
        self.setStyleSheet(f"background-color: {THEME['background_dark']};")
        self.center_window()

    def center_window(self):
        screen = self.screen().geometry()
        x = (screen.width() - self.width()) // 2
        y = (screen.height() - self.height()) // 2
        self.move(x, y)

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        main_layout.addWidget(self._create_titlebar())

        body_widget = QWidget()
        body_layout = QHBoxLayout(body_widget)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        body_layout.addWidget(self._create_sidebar())

        self.content_stack = QStackedWidget()
        self.content_stack.addWidget(self._create_home_view())
        self.steam_view = SteamView()
        self.content_stack.addWidget(self.steam_view)
        self.tools_view = ToolsView()
        self.content_stack.addWidget(self.tools_view)

        body_layout.addWidget(self.content_stack)
        main_layout.addWidget(body_widget)

    def _create_titlebar(self) -> QWidget:
        tb = QWidget()
        tb.setFixedHeight(40)
        tb.setStyleSheet(f"background-color: {THEME['sidebar_bg']}; border-bottom: 1px solid {THEME['border_color']};")
        tb_layout = QHBoxLayout(tb)
        tb_layout.setContentsMargins(16, 0, 16, 0)

        title = QLabel(f"⚡ {APP_NAME} <span style='font-size:11px; color:#9ca3af;'>v{APP_VERSION}</span>")
        title.setTextFormat(Qt.TextFormat.RichText)
        title.setStyleSheet("color: white; font-weight: bold; font-size: 13px;")
        tb_layout.addWidget(title)

        tb_layout.addStretch()

        min_btn = QPushButton("—")
        max_btn = QPushButton("⬜")
        close_btn = QPushButton("✕")

        for btn, action in [(min_btn, self.showMinimized), (max_btn, self._toggle_maximize), (close_btn, self.close)]:
            btn.setFixedSize(30, 30)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    color: {THEME['text_secondary']};
                    border: none;
                    font-size: 13px;
                }}
                QPushButton:hover {{
                    background-color: {THEME['background_card_hover']};
                    color: white;
                }}
            """)
            if btn == close_btn:
                btn.setStyleSheet(btn.styleSheet() + f"QPushButton:hover {{ background-color: {THEME['accent_red']}; }}")
            btn.clicked.connect(action)
            tb_layout.addWidget(btn)

        return tb

    def _toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def _create_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setFixedWidth(200)
        sidebar.setStyleSheet(f"background-color: {THEME['sidebar_bg']}; border-right: 1px solid {THEME['border_color']};")
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(12, 16, 12, 16)
        layout.setSpacing(6)

        nav_items = [
            ("🏠 Kütüphane", lambda: self._show_view(0)),
            ("🌐 Steam Mağazası", lambda: self._show_view(1)),
            ("🔧 Araçlar & Eklentiler", lambda: self._show_view(2)),
            ("📥 Oyun Talebi", lambda: RequestGameDialog(self).exec()),
            ("⚙️ Ayarlar", lambda: SettingsDialog(self).exec()),
            ("❤️ Destek Ol", lambda: SupportDialog(self).exec()),
        ]

        for text, callback in nav_items:
            btn = QPushButton(text)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: {THEME['text_secondary']};
                    border-radius: 8px;
                    padding: 10px 14px;
                    text-align: left;
                    font-size: 13px;
                    font-weight: 500;
                    border: none;
                }}
                QPushButton:hover {{
                    background-color: {THEME['background_card']};
                    color: white;
                }}
            """)
            btn.clicked.connect(callback)
            layout.addWidget(btn)

        layout.addStretch()

        self.cart_btn = QPushButton("🛒 Toplu İndirme (0)")
        self.cart_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['accent_red']};
                color: white;
                border-radius: 8px;
                padding: 10px;
                font-weight: bold;
                font-size: 12px;
            }}
        """)
        self.cart_btn.clicked.connect(self._show_bulk_cart)
        layout.addWidget(self.cart_btn)

        return sidebar

    def _show_view(self, index: int):
        self.content_stack.setCurrentIndex(index)

    def _create_home_view(self) -> QWidget:
        view = QWidget()
        layout = QVBoxLayout(view)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        top_bar = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Oyun adı veya etiket ara...")
        self.search_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {THEME['background_card']};
                color: white;
                border-radius: 8px;
                padding: 10px 16px;
                border: 1px solid {THEME['border_color']};
                font-size: 13px;
            }}
            QLineEdit:focus {{
                border: 1px solid {THEME['border_focus']};
            }}
        """)
        self.search_input.textChanged.connect(self.on_search_text_changed)
        top_bar.addWidget(self.search_input)

        layout.addLayout(top_bar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("border: none; background: transparent;")

        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(16)
        self.scroll.setWidget(self.grid_container)
        layout.addWidget(self.scroll)

        pag_layout = QHBoxLayout()
        pag_layout.setContentsMargins(0, 4, 0, 0)

        self.prev_btn = QPushButton("← Önceki")
        self.next_btn = QPushButton("Sonraki →")
        for btn in [self.prev_btn, self.next_btn]:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {THEME['background_card']};
                    color: white;
                    border-radius: 6px;
                    padding: 6px 14px;
                    border: 1px solid {THEME['border_color']};
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: {THEME['background_card_hover']};
                }}
            """)
        self.prev_btn.clicked.connect(self.previous_page)
        self.next_btn.clicked.connect(self.next_page)

        self.page_label = QLabel("Sayfa 1 / 1")
        self.page_label.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 12px;")

        pag_layout.addWidget(self.prev_btn)
        pag_layout.addWidget(self.page_label)
        pag_layout.addWidget(self.next_btn)
        pag_layout.addStretch()

        layout.addLayout(pag_layout)
        return view

    def load_games_data(self):
        self.scrape_worker = LiveScrapeWorker(self.api_client)
        self.scrape_worker.scraped.connect(self._on_games_loaded)
        self.scrape_worker.start()

    def _on_games_loaded(self, games: list):
        if games:
            self.all_games = games
        else:
            self.all_games = [
                {"app_id": 730, "name": "Counter-Strike 2", "is_bypass": True, "has_online_fix": True},
                {"app_id": 1091500, "name": "Cyberpunk 2077", "is_bypass": True, "has_online_fix": False},
                {"app_id": 1172470, "name": "Apex Legends", "is_bypass": True, "has_online_fix": True},
                {"app_id": 1245620, "name": "ELDEN RING", "is_bypass": True, "has_online_fix": True},
                {"app_id": 271590, "name": "Grand Theft Auto V", "is_bypass": True, "has_online_fix": True},
                {"app_id": 1086940, "name": "Baldur's Gate 3", "is_bypass": True, "has_online_fix": True},
                {"app_id": 814380, "name": "Sekiro: Shadows Die Twice", "is_bypass": True, "has_online_fix": False},
                {"app_id": 252490, "name": "Rust", "is_bypass": True, "has_online_fix": True},
            ]
        self.filtered_games = list(self.all_games)
        self.display_games()

    def display_games(self):
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        start_idx = (self.current_page - 1) * self.games_per_page
        end_idx = start_idx + self.games_per_page
        current_batch = self.filtered_games[start_idx:end_idx]

        cols = 4
        for i, game in enumerate(current_batch):
            row = i // cols
            col = i % cols
            app_id = game.get("app_id") or game.get("appid", 0)
            is_inst = app_id in self.installed_appids
            card = GameCard(game, is_installed=is_inst)
            card.clicked.connect(self.show_game_detail)
            card.cart_toggled.connect(self._on_cart_toggled)
            self.grid_layout.addWidget(card, row, col)

        total_pages = max(1, (len(self.filtered_games) + self.games_per_page - 1) // self.games_per_page)
        self.page_label.setText(f"Sayfa {self.current_page} / {total_pages}")
        self.prev_btn.setEnabled(self.current_page > 1)
        self.next_btn.setEnabled(self.current_page < total_pages)

    def _on_cart_toggled(self, game_data: dict, is_selected: bool):
        self.cart_btn.setText(f"🛒 Toplu İndirme ({self.cart_manager.count()})")

    def _show_bulk_cart(self):
        cart_items = self.cart_manager.get_cart()
        if not cart_items:
            QMessageBox.information(self, "Sepet Boş", "Toplu indirme için önce oyun kartlarındaki 'Seç' kutucuğunu işaretleyin.")
            return
        names = "\n".join([f"• {g.get('name')}" for g in cart_items])
        ret = QMessageBox.question(
            self,
            "Toplu İndirme",
            f"Seçilen {len(cart_items)} oyun kütüphaneye eklensin mi?\n\n{names}"
        )
        if ret == QMessageBox.StandardButton.Yes:
            self.steam_manager.run_steam_firewall_cycle()
            self.cart_manager.clear()
            self.cart_btn.setText("🛒 Toplu İndirme (0)")
            QMessageBox.information(self, "Başarılı", "Oyunlar Steam kütüphanenize eklendi.")

    def on_search_text_changed(self, text: str):
        q = text.strip()
        if not q:
            self.filtered_games = list(self.all_games)
        else:
            scored = []
            for g in self.all_games:
                name = g.get("name", "")
                score = self.backend.calculate_search_score(q, name)
                if score > 20.0:
                    scored.append((score, g))
            scored.sort(key=lambda x: x[0], reverse=True)
            self.filtered_games = [item[1] for item in scored]

        self.current_page = 1
        self.display_games()

    def show_game_detail(self, game_data: dict):
        dialog = GameDetailDialog(game_data, self)
        dialog.exec()

    def previous_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.display_games()

    def next_page(self):
        total_pages = (len(self.filtered_games) + self.games_per_page - 1) // self.games_per_page
        if self.current_page < total_pages:
            self.current_page += 1
            self.display_games()

    def check_for_updates(self):
        self.update_worker = UpdateWorker(self.update_manager)
        self.update_worker.update_available.connect(self._on_update_available)
        self.update_worker.start()

    def _on_update_available(self, new_ver: str, dl_url: str):
        pass

    def setup_tray_icon(self):
        self.tray = QSystemTrayIcon(self)
        icon_path = get_icon_path("icon")
        if icon_path:
            self.tray.setIcon(QIcon(icon_path))
        else:
            self.tray.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_ComputerIcon))

        menu = QMenu()
        show_action = menu.addAction("Göster")
        show_action.triggered.connect(self.show)
        exit_action = menu.addAction("Çıkış")
        exit_action.triggered.connect(self.close)

        self.tray.setContextMenu(menu)
        self.tray.show()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and not self.isMaximized():
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()
