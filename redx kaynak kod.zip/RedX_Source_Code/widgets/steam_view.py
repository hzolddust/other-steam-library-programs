"""
RedX Game Library - Steam View
"""
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit
from PyQt6.QtCore import pyqtSignal, QUrl
from PyQt6.QtWebEngineWidgets import QWebEngineView

from config import STEAM_STORE_URL, THEME, get_icon_path


class SteamView(QWidget):
    add_game_requested = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        toolbar = QWidget()
        toolbar.setStyleSheet(f"background-color: {THEME['background_dark']}; padding: 6px; border-bottom: 1px solid {THEME['border_color']};")
        tb_layout = QHBoxLayout(toolbar)
        tb_layout.setContentsMargins(8, 4, 8, 4)

        self.back_btn = QPushButton("←")
        self.forward_btn = QPushButton("→")
        self.reload_btn = QPushButton("↻")
        for btn in [self.back_btn, self.forward_btn, self.reload_btn]:
            btn.setFixedSize(32, 32)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {THEME['background_card']};
                    color: white;
                    border-radius: 6px;
                    font-weight: bold;
                    border: 1px solid {THEME['border_color']};
                }}
                QPushButton:hover {{
                    background-color: {THEME['background_card_hover']};
                }}
            """)

        self.url_bar = QLineEdit()
        self.url_bar.setText(STEAM_STORE_URL)
        self.url_bar.setStyleSheet(f"""
            QLineEdit {{
                background-color: {THEME['background_card']};
                color: #ffffff;
                border-radius: 6px;
                padding: 6px 12px;
                border: 1px solid {THEME['border_color']};
            }}
        """)
        self.url_bar.returnPressed.connect(self._navigate)

        tb_layout.addWidget(self.back_btn)
        tb_layout.addWidget(self.forward_btn)
        tb_layout.addWidget(self.reload_btn)
        tb_layout.addWidget(self.url_bar)

        layout.addWidget(toolbar)

        self.browser = QWebEngineView()
        self.browser.setUrl(QUrl(STEAM_STORE_URL))
        self.browser.loadFinished.connect(self._on_load_finished)
        self.browser.urlChanged.connect(lambda qurl: self.url_bar.setText(qurl.toString()))

        self.back_btn.clicked.connect(self.browser.back)
        self.forward_btn.clicked.connect(self.browser.forward)
        self.reload_btn.clicked.connect(self.browser.reload)

        layout.addWidget(self.browser)

    def _navigate(self):
        url_text = self.url_bar.text().strip()
        if not url_text.startswith("http"):
            url_text = "https://" + url_text
        self.browser.setUrl(QUrl(url_text))

    def _on_load_finished(self, success: bool):
        if success:
            self._inject_button_script()

    def _inject_button_script(self):
        js_code = r"""
        (function() {
            if (document.getElementById('redx-quick-btn')) return;
            const match = window.location.pathname.match(/\/app\/(\\d+)/);
            if (!match) return;
            const appid = match[1];

            const btn = document.createElement('button');
            btn.id = 'redx-quick-btn';
            btn.innerText = '⚡ RedX ile Kütüphaneye Ekle';
            btn.style.position = 'fixed';
            btn.style.bottom = '20px';
            btn.style.right = '20px';
            btn.style.zIndex = '99999';
            btn.style.padding = '12px 24px';
            btn.style.backgroundColor = '#e50914';
            btn.style.color = '#ffffff';
            btn.style.border = 'none';
            btn.style.borderRadius = '8px';
            btn.style.fontWeight = 'bold';
            btn.style.fontSize = '14px';
            btn.style.cursor = 'pointer';
            btn.style.boxShadow = '0 4px 15px rgba(229, 9, 20, 0.4)';

            btn.onclick = function() {
                console.log('REDX_ADD_GAME:' + appid);
            };

            document.body.appendChild(btn);
        })();
        """
        self.browser.page().runJavaScript(js_code)
