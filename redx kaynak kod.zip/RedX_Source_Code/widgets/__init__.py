"""Widgets package."""
from .game_card import GameCard
from .steam_view import SteamView
from .tools_view import ToolsView
from .dialogs import (
    GameDetailDialog,
    VersionSelectionDialog,
    SteamRestartSuccessDialog,
    SteamCheckGamesDialog,
    SettingsDialog,
    RequestGameDialog,
    SupportDialog
)
from .main_window import MainWindow

__all__ = [
    'GameCard',
    'SteamView',
    'ToolsView',
    'GameDetailDialog',
    'VersionSelectionDialog',
    'SteamRestartSuccessDialog',
    'SteamCheckGamesDialog',
    'SettingsDialog',
    'RequestGameDialog',
    'SupportDialog',
    'MainWindow'
]
