"""
RedX Game Library - Game Card Widget
"""
import os
from PyQt6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QCheckBox, QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize
from PyQt6.QtGui import QPixmap, QColor, QPainter, QPainterPath, QCursor

from config import THEME, get_icon_path
from utils.cart_manager import CartManager
from utils.workers import ImageLoadWorker


class GameCard(QFrame):
    clicked = pyqtSignal(dict)
    install_clicked = pyqtSignal(dict)
    cart_toggled = pyqtSignal(dict, bool)

    def __init__(self, game_data: dict, parent=None, is_installed=False):
        super().__init__(parent)
        self.game_data = game_data
        self.app_id = game_data.get("app_id") or game_data.get("appid", 0)
        self.name = game_data.get("name", "Bilinmeyen Oyun")
        self.image_url = game_data.get("image_url") or game_data.get("header_image", "")
        self.is_installed = is_installed
        self.is_bypass = game_data.get("is_bypass", True)
        self.has_online_fix = game_data.get("has_online_fix", False)
        self.cart_manager = CartManager.get_instance()

        self.setup_ui()
        self.load_image_async()

    def setup_ui(self):
        self.setFixedSize(220, 310)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.setStyleSheet(f"""
            GameCard {{
                background-color: {THEME['background_card']};
                border-radius: 12px;
                border: 1px solid {THEME['border_color']};
            }}
            GameCard:hover {{
                background-color: {THEME['background_card_hover']};
                border: 1px solid {THEME['border_focus']};
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.image_label = QLabel()
        self.image_label.setFixedSize(200, 115)
        self.image_label.setStyleSheet("border-radius: 8px; background-color: #0b0d13;")
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setText("Yükleniyor...")
        layout.addWidget(self.image_label)

        self.title_label = QLabel(self.name)
        self.title_label.setStyleSheet("color: #ffffff; font-size: 13px; font-weight: bold;")
        self.title_label.setWordWrap(True)
        self.title_label.setMaximumHeight(36)
        layout.addWidget(self.title_label)

        badge_layout = QHBoxLayout()
        badge_layout.setSpacing(4)

        if self.is_installed:
            inst_badge = QLabel("KURULU")
            inst_badge.setStyleSheet(f"background-color: {THEME['accent_green']}; color: white; border-radius: 4px; font-size: 10px; font-weight: bold; padding: 2px 5px;")
            badge_layout.addWidget(inst_badge)

        if self.is_bypass:
            bypass_badge = QLabel("BYPASS")
            bypass_badge.setStyleSheet(f"background-color: {THEME['accent_blue']}; color: white; border-radius: 4px; font-size: 10px; font-weight: bold; padding: 2px 5px;")
            badge_layout.addWidget(bypass_badge)

        if self.has_online_fix:
            fix_badge = QLabel("ONLINE FIX")
            fix_badge.setStyleSheet(f"background-color: {THEME['accent_yellow']}; color: black; border-radius: 4px; font-size: 10px; font-weight: bold; padding: 2px 5px;")
            badge_layout.addWidget(fix_badge)

        badge_layout.addStretch()
        layout.addLayout(badge_layout)
        layout.addStretch()

        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 0, 0, 0)

        self.cart_cb = QCheckBox("Seç")
        self.cart_cb.setChecked(self.cart_manager.is_selected(self.app_id))
        self.cart_cb.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 11px;")
        self.cart_cb.clicked.connect(self._on_cart_clicked)
        bottom_layout.addWidget(self.cart_cb)

        bottom_layout.addStretch()

        self.action_btn = QPushButton("İncele")
        self.action_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['accent_red']};
                color: white;
                border-radius: 6px;
                padding: 4px 10px;
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {THEME['accent_red_hover']};
            }}
        """)
        self.action_btn.clicked.connect(lambda: self.clicked.emit(self.game_data))
        bottom_layout.addWidget(self.action_btn)

        layout.addLayout(bottom_layout)

    def _on_cart_clicked(self):
        self.cart_manager.toggle(self.game_data)
        self.cart_cb.setChecked(self.cart_manager.is_selected(self.app_id))
        self.cart_toggled.emit(self.game_data, self.cart_manager.is_selected(self.app_id))

    def load_image_async(self):
        if not self.image_url:
            if self.app_id:
                self.image_url = f"https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{self.app_id}/header.jpg"
            else:
                return

        self.worker = ImageLoadWorker(self.image_url, str(self.app_id))
        self.worker.loaded.connect(self._on_image_loaded)
        self.worker.start()

    def _on_image_loaded(self, img_bytes: bytes, identifier: str):
        pixmap = QPixmap()
        if pixmap.loadFromData(img_bytes):
            scaled = pixmap.scaled(
                200, 115,
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation
            )
            rounded = QPixmap(scaled.size())
            rounded.fill(Qt.GlobalColor.transparent)
            painter = QPainter(rounded)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            path = QPainterPath()
            path.addRoundedRect(0, 0, scaled.width(), scaled.height(), 8, 8)
            painter.setClipPath(path)
            painter.drawPixmap(0, 0, scaled)
            painter.end()

            self.image_label.setPixmap(rounded)
            self.image_label.setText("")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.game_data)
        super().mousePressEvent(event)
