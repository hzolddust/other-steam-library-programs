"""
RedX Game Library - Tools View
"""
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QFrame
)
from PyQt6.QtCore import Qt

from config import THEME, get_icon_path
from utils.steam_manager import SteamManager


class ToolsView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.steam_manager = SteamManager.get_instance()
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        title = QLabel("Araçlar ve Eklentiler")
        title.setStyleSheet("font-size: 22px; font-weight: bold; color: white;")
        layout.addWidget(title)

        desc = QLabel("Steam kütüphanenizi optimize etmek, bypass ve hata düzeltme komutlarını çalıştırmak için kullanışlı araçlar.")
        desc.setStyleSheet(f"color: {THEME['text_secondary']}; font-size: 13px;")
        layout.addWidget(desc)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background: transparent;")

        container = QWidget()
        c_layout = QVBoxLayout(container)
        c_layout.setSpacing(12)

        tools = [
            {
                "name": "Steam Error Fix (steam.run)",
                "desc": "Steam bağlantı ve başlatma hatalarını PowerShell komutuyla otomatik onarır.",
                "action": self.steam_manager.fix_steam_errors,
                "btn": "Onarımı Çalıştır"
            },
            {
                "name": "RedX Fix Script",
                "desc": "Eksik manifest ve DLL dosyalarını tespit eder ve en güncel sürümleri indirir.",
                "action": self.steam_manager.run_redx_fix_script,
                "btn": "Fix Scriptini Başlat"
            },
            {
                "name": "Steam Registry & İzin Düzeltici",
                "desc": "Windows Registry kayıtlarını ve Steam klasör izinlerini varsayılan ayarlara döndürür.",
                "action": self.steam_manager.fix_regedit_error,
                "btn": "Registry Onar"
            },
            {
                "name": "Steam Güvenlik Duvarı Yenileyici",
                "desc": "Steam dış bağlantılarını 8 saniyeliğine durdurup tekrar açarak yeni eklenen oyunları Steam kütüphanesine tanıtır.",
                "action": self.steam_manager.run_steam_firewall_cycle,
                "btn": "Döngüyü Başlat"
            }
        ]

        for t in tools:
            card = self._create_tool_card(t)
            c_layout.addWidget(card)

        c_layout.addStretch()
        scroll.setWidget(container)
        layout.addWidget(scroll)

    def _create_tool_card(self, tool_info: dict) -> QFrame:
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {THEME['background_card']};
                border-radius: 10px;
                border: 1px solid {THEME['border_color']};
                padding: 16px;
            }}
            QFrame:hover {{
                border: 1px solid {THEME['border_focus']};
            }}
        """)
        layout = QHBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)

        info_layout = QVBoxLayout()
        t_name = QLabel(tool_info["name"])
        t_name.setStyleSheet("font-size: 15px; font-weight: bold; color: white;")
        t_desc = QLabel(tool_info["desc"])
        t_desc.setStyleSheet(f"font-size: 12px; color: {THEME['text_secondary']};")
        t_desc.setWordWrap(True)

        info_layout.addWidget(t_name)
        info_layout.addWidget(t_desc)
        layout.addLayout(info_layout)
        layout.addStretch()

        btn = QPushButton(tool_info["btn"])
        btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {THEME['accent_red']};
                color: white;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {THEME['accent_red_hover']};
            }}
        """)
        btn.clicked.connect(tool_info["action"])
        layout.addWidget(btn)

        return card
