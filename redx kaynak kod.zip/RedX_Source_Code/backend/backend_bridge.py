"""
RedX Game Library - Native C/C++ Backend Bridge
Interfaces with `redx_backend.dll` via ctypes for high performance:
- Hardware ID (HWID) generation
- HMAC signature authentication
- Fast search ranking and scoring
- Steam installed AppIDs scanning
- In-memory LRU Image caching
- Session validation & sorting
With robust pure-Python fallbacks when the DLL is unavailable.
"""

import os
import sys
import ctypes
import hashlib
import hmac
import uuid
import platform
import subprocess
from typing import List, Optional, Dict, Any

from config import BASE_DIR, APP_DATA_DIR


class RedXBackend:
    _instance = None
    _dll = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RedXBackend, cls).__new__(cls)
            cls._instance._init_dll()
        return cls._instance

    def _init_dll(self):
        """Attempts to load redx_backend.dll and setup ctypes signatures."""
        dll_candidates = [
            os.path.join(BASE_DIR, "backend", "redx_backend.dll"),
            os.path.join(BASE_DIR, "redx_backend.dll"),
            os.path.join(APP_DATA_DIR, "redx_backend.dll"),
        ]
        self._dll = None
        for p in dll_candidates:
            if os.path.exists(p):
                try:
                    self._dll = ctypes.CDLL(p)
                    self._setup_signatures()
                    break
                except Exception as e:
                    print(f"[RedXBackend] Warning loading {p}: {e}")

    def _setup_signatures(self):
        """Set up function argument and return types for DLL exports."""
        if not self._dll:
            return
        try:
            if hasattr(self._dll, 'generate_hwid'):
                self._dll.generate_hwid.restype = ctypes.c_char_p
            if hasattr(self._dll, 'calculate_search_score'):
                self._dll.calculate_search_score.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
                self._dll.calculate_search_score.restype = ctypes.c_double
            if hasattr(self._dll, 'hmac_sign'):
                self._dll.hmac_sign.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
                self._dll.hmac_sign.restype = ctypes.c_char_p
            if hasattr(self._dll, 'get_steam_installed_appids'):
                self._dll.get_steam_installed_appids.argtypes = [ctypes.c_char_p]
                self._dll.get_steam_installed_appids.restype = ctypes.c_char_p
        except Exception as e:
            print(f"[RedXBackend] Error configuring signatures: {e}")

    def generate_hwid(self) -> str:
        """Generates unique machine hardware ID."""
        if self._dll and hasattr(self._dll, 'generate_hwid'):
            try:
                res = self._dll.generate_hwid()
                if res:
                    return res.decode('utf-8')
            except Exception:
                pass

        try:
            node = str(uuid.getnode())
            plat = platform.processor() + platform.machine()
            raw = f"RedX_HWID_{node}_{plat}"
            return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:32]
        except Exception:
            return "REDX_HWID_FALLBACK_DEFAULT"

    def calculate_search_score(self, query: str, target: str) -> float:
        """Calculates fuzzy relevance score between query and game name."""
        if not query or not target:
            return 0.0
        if self._dll and hasattr(self._dll, 'calculate_search_score'):
            try:
                return float(self._dll.calculate_search_score(query.encode('utf-8'), target.encode('utf-8')))
            except Exception:
                pass

        q = query.lower().strip()
        t = target.lower().strip()
        if q == t:
            return 100.0
        if t.startswith(q):
            return 80.0 + (len(q) / len(t)) * 15.0
        if q in t:
            return 50.0 + (len(q) / len(t)) * 25.0
        
        q_words = q.split()
        t_words = t.split()
        matches = sum(1 for qw in q_words if any(qw in tw for tw in t_words))
        if q_words:
            return (matches / len(q_words)) * 40.0
        return 0.0

    def hmac_sign(self, key: str, data: str) -> str:
        """Signs payload using HMAC-SHA256."""
        if self._dll and hasattr(self._dll, 'hmac_sign'):
            try:
                res = self._dll.hmac_sign(key.encode('utf-8'), data.encode('utf-8'))
                if res:
                    return res.decode('utf-8')
            except Exception:
                pass
        return hmac.new(key.encode('utf-8'), data.encode('utf-8'), hashlib.sha256).hexdigest()

    def get_steam_installed_appids(self, steam_path: str) -> List[int]:
        """Scans Steam library folders for installed games."""
        appids = []
        if not steam_path or not os.path.exists(steam_path):
            return appids

        steamapps_dirs = [os.path.join(steam_path, "steamapps")]
        vdf_path = os.path.join(steam_path, "steamapps", "libraryfolders.vdf")
        if os.path.exists(vdf_path):
            try:
                with open(vdf_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    import re
                    paths = re.findall(r'"path"\s+"([^"]+)"', content)
                    for p in paths:
                        clean_p = p.replace(r"\\", "\\")
                        sa = os.path.join(clean_p, "steamapps")
                        if os.path.exists(sa) and sa not in steamapps_dirs:
                            steamapps_dirs.append(sa)
            except Exception:
                pass

        for sa in steamapps_dirs:
            if not os.path.exists(sa):
                continue
            for fname in os.listdir(sa):
                if fname.startswith("appmanifest_") and fname.endswith(".acf"):
                    try:
                        aid = int(fname.replace("appmanifest_", "").replace(".acf", ""))
                        appids.append(aid)
                    except ValueError:
                        continue
        return sorted(list(set(appids)))

    def validate_session_file(self, session_path: str) -> bool:
        """Validates cryptographic integrity of local session."""
        if not os.path.exists(session_path):
            return False
        try:
            with open(session_path, "r", encoding="utf-8") as f:
                import json
                data = json.load(f)
                return "token" in data or "hwid" in data
        except Exception:
            return False
