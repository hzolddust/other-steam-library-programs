# RedX Game Library - Reconstructed Source Code

Bu qovluq **RedX Game Library** tətbiqinin ikili faylından (`RedXGameLibrary.exe`, `main.dll`, `redx_backend.dll`) tərs mühəndislik (reverse engineering) yolu ilə bərpa edilmiş təmiz və modulyar mənbə kodlarını ehtiva edir.

---

## 🔍 Tərs Mühəndislik Təhlili və Nəticələri

1. **Memarlıq Quruluşu (Architecture)**:
   - Tətbiq əvvəlcə Electron hesab edilsə də, dərin ikili təhlil nəticəsində aşkar olundu ki, layihə **Python 3.12 (PyQt6 + QtWebEngine)** və **C/C++ Backend DLL (`redx_backend.dll`)** ilə yazılmış və **Nuitka** vasitəsilə tək icra olunan fayl (`.exe`) halına gətirilmişdir.
   - Brauzer daxilində Steam mağazası ilə inteqrasiya üçün **QtWebEngine** və dinamik JavaScript injection mexanizmlərindən istifadə edilir.

2. **C/C++ Backend Funksiyaları (`redx_backend.dll`)**:
   - `generate_hwid`: Prosessor və anakart UUID əsaslı aparat ID-si yaradılması.
   - `calculate_search_score`: Oyun axtarışında yüksək performanslı bulanıq (fuzzy) xallama alqoritmi.
   - `get_steam_installed_appids`: Diskdəki Steam `appmanifest_*.acf` fayllarını oxuyaraq quraşdırılmış oyunların siyahılanması.
   - `hmac_sign`: API sorğularının HMAC-SHA256 imzalanması.
   - `image_cache_*`: Şəkillərin yaddaşda sürətli keşlənməsi.

3. **Steam İnteqrasiyası və Firewall Döngüsü**:
   - Manifest faylları yeniləndikdən sonra `netsh advfirewall` vasitəsilə 8 saniyəlik bloklama və açma döngüsü həyata keçirilərək Steam kütüpxanasının yenidən yüklənməsi təmin edilir.

---

## 📁 Qovluq Quruluşu

- `main.py` - Tətbiqin əsas icra və başladılma nöqtəsi.
- `config.py` - Qlobal konfiqurasiya, API URL-ləri, mövzu rəngləri və yollar.
- `backend/`
  - `backend_bridge.py` - `redx_backend.dll` ilə ctypes əlaqəsi və Python alternativləri.
  - `redx_backend.dll` - Əsas C++ dinamik kitabxanası.
- `api/`
  - `api_client.py` - RedX API, Steam Store API, SteamCMD və ManifestHub şəbəkə modulu.
- `utils/`
  - `steam_manager.py` - Steam axtarışı, Registry, proses idarəetməsi və təmir skriptləri.
  - `cart_manager.py` - Toplu oyun seçimi (5 oyuna qədər) üçün Singleton idarəedici.
  - `update_manager.py` - Avtomatik yeniləmə və PowerShell skripti ilə restart.
  - `workers.py` - Fon əməliyyatları üçün PyQt6 QThread işçiləri.
- `widgets/`
  - `main_window.py` - Çərçivəsiz əsas pəncərə, yan menyu, axtarış, filtr və səhifələmə.
  - `game_card.py` - Oyun kartları, asinxron örtük şəkli, nişanlar və animasiyalar.
  - `steam_view.py` - İnteqrasiya olunmuş QtWebEngine Steam mağazası və JS injection.
  - `tools_view.py` - Eklentilər və onarım alətləri görünüşü.
  - `dialogs.py` - Oyun detalları (v3.8), Sürüm seçimi, Ayarlar və Onarım dialoqları.
- `resources/`
  - `icons/` - Bütün SVG və PNG ikonları.

---

## 🚀 Quraşdırma və İşə Salma

Tələb olunan Python paketlərini quraşdırın:

```bash
pip install -r requirements.txt
```

Tətbiqi işə salmaq üçün:

```bash
python main.py
```
